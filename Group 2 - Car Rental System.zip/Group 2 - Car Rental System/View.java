import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class View extends JFrame implements ActionListener
{
    JButton aids = new JButton("Press for free robux");
    JLabel title = new JLabel("Available Cars:");
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();
    
    ImageIcon card = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car1.jpg");
    JButton c1 = new JButton(card);
    ImageIcon card1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car2.jpeg");
    JButton c2 = new JButton(card1);
    ImageIcon card2 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car3.png");
    JButton c3 = new JButton(card2);
    ImageIcon card3 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car4.jpg");
    JButton c4 = new JButton(card3);
    ImageIcon card4 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Back1.jpg");
    JButton back = new JButton(card4);
    ImageIcon card5 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Next.jpg");
    JButton next = new JButton(card5);
    
    JLabel details = new JLabel("Vehicle Details");
    JTextArea carDetails = new JTextArea(6,25);
    JTextArea carDetails1 = new JTextArea(6,25);
    public View()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,900,450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 0;
        gc.gridy = 0;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridy = 1;
        p.add(c1,gc);
        gc.gridx = 1;
        p.add(c2,gc);
        gc.gridx = 0;
        gc.gridy = 2;
        p.add(c3,gc);
        gc.gridx = 1;
        p.add(c4,gc);
        gc.gridx = 2;
        gc.gridy = 0;
        details.setFont(title.getFont().deriveFont(35.0f));
        p.add(details,gc);
        gc.gridx = 2;
        gc.gridy = 1;
        carDetails.setEditable(false);
        carDetails.setText("Click on a Car\nfor more Details");
        p.add(carDetails,gc);
        gc.gridy = 2;
        carDetails1.setEditable(false);
        p.add(carDetails1,gc);
        gc.gridx = 0;
        gc.gridy = 3;
        p.add(back,gc);
        gc.gridx = 1;
        p.add(next,gc);
        addActionEvent();
    }
    private void addActionEvent()
    {
        c1.addActionListener(this);
        c2.addActionListener(this);
        c3.addActionListener(this);
        c4.addActionListener(this);
        back.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) 
    {
        Object source = e.getSource();
        if (source == c1)
        {
            carDetails.setText("Model: Lightning McQueen\nYear Model: 2006\nType: Race Car\nPlate Number: 95\nColor: Red\nRental Price: Php 450");
            carDetails1.setText("Speed, I am speed.\nBark, Bark Bark!\nVery Fast Car, Car Go Vroom Vroom\nVery Famous Car, Car Go Vroom Vroom\nGood for Drag Racing, Car Go Vroom Vroom\nWon Piston Cup A Lot of Time\nRetired, Car No Go Vroom Vroom");
        } else if (source == c2)
        {
            carDetails1.setText("This Bicycle is definitely not stolen. \nHowever, we require a lot of money when this\nis rented. Why you ask? Well...\nIt's not stealing when it's up for grabs.\nWarning: If someone tells you it's their bike\nthey are lieing.");
            carDetails.setText("Model: Stolen Bicycle\nYear Model: ????\nType: Bicycle\nPlate Number: N/A\nColor: Black?\nRental Price: Php 20,000");
        } else if (source == c3)
        {
            carDetails1.setText("Zoom through the Mushroom Kingdom.\nTravel through Bowser's Kingdom\nDrive through Hyrule Kingdom\nDrift through Rainbow Road\nWhy do we have this? Well...\nThe past owner always get last place\nthat's why.");
            carDetails.setText("Model: Prancer\nYear Model: Mario Kart 8\nType: Horse Powered Race Car\nPlate Number: Neigh\nColor: Multi-Colored\nRental Price: Php 600");
        } else if (source == c4)
        {
            carDetails1.setText("It's a bird, it's a plane, no it's not\nBecause no one knows what it is.\nVery suitable for a road trip through Earth\nand Space with your family.\nWarning: Our Party is not liable for\nany deaths or damages caused by this vehicle.\nWarning: Cow has not returned.");
            carDetails.setText("Model: Unidentified Flying Object\nYear Model: From the Future\nType: Airplane\nPlate Number: dsajbhwbaidw\nColor: Grey\nRental Price: Free As Long We Are Not Liable\nFor Any Potential Damages");
        } else if (source == back)
        {
            this.dispose();
            new UI().show();
        } else if (source == next)
        {
            
        }
    }
}
