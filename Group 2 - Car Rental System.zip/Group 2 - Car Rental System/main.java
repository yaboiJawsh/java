public class main
{
    //Customer Info:
    String fName, lName, birthMonth, address, gender, status;
    int birthDate, birthYear, contact, age = 0;
    //Rental Info
    String currentMonth, pickMonth, returnMonth;
    int currentDate, pickDate, returnDate, currentYear, pickYear, returnYear;
    public static void main(String[] args)
    {
        new UI().show();
    }
}

