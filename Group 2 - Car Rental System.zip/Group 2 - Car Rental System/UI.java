import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UI extends JFrame implements ActionListener
{
    JLabel title = new JLabel("Group 2 - Car/Vehicle Rental",JLabel.CENTER);
    JLabel title1 = new JLabel("System",JLabel.CENTER);
    
    JButton view = new JButton("Car / Vehicle List");
    JButton rent = new JButton("Rent a Car / Vehicle");
    JButton locations = new JButton("Available Locations");
    JButton aboutus = new JButton("About Us");
    JButton exit = new JButton("Exit");
    
    
    
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();

    public UI()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 0;
        gc.gridy = 0;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridy = 1;
        title1.setFont(title.getFont().deriveFont(35.0f));
        p.add(title1,gc);
        gc.gridy = 2;
        p.add(view,gc);
        gc.gridy = 3;
        p.add(rent,gc);
        gc.gridy = 4;
        p.add(locations,gc);
        gc.gridy = 5;
        p.add(aboutus,gc);
        gc.gridy = 6;
        p.add(exit,gc);
        addActionEvent();
        
    }
    private void addActionEvent()
    {
        exit.addActionListener(this);
        aboutus.addActionListener(this);
        locations.addActionListener(this);
        rent.addActionListener(this);
        view.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) 
    {
        Object source = e.getSource();
        if (source == exit)
        {
            JFrame f;
            f = new JFrame();
            int exitoption = JOptionPane.showConfirmDialog(f,"Are you sure you want to exit the program?","EXIT",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
            if(exitoption == 0) {
                System.exit(0);
             }
             else if (exitoption == 1){
                //Good day po di po namin alam ilalagay dito hehe
            }
        } else if (source == aboutus)
        {
            new About_Us().show();
            this.dispose();
        } else if (source == locations)
        {
            new Locations().show();
            this.dispose();
        } else if (source == view)
        {
            new View().show();
            this.dispose();
        } else if (source == rent)
        {
            new Rent().show();
            this.dispose();
        }
    }
}
