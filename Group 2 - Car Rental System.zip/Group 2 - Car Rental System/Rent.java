import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Rent extends JFrame implements ActionListener
{
    JButton aids = new JButton("Press for free robux");
    JLabel title = new JLabel("Rental Information:",SwingConstants.CENTER);
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();
    
    JLabel pickup = new JLabel("Picking Up");
    JLabel dropoff = new JLabel("Dropping Off");
    JLabel pMonth = new JLabel("Pickup Month");
    JLabel pDay = new JLabel("Pickup Day");
    JLabel rMonth = new JLabel("Return Month");
    JLabel rDay = new JLabel("Return Day");
    JLabel nameL = new JLabel("Enter Full Name (First, MI, Last):");
    JLabel contactL = new JLabel("Enter Contact Number:");
    
    JTextField name = new JTextField("");
    JTextField contacts = new JTextField("");
    
    String[] pLoc = {"Choose a Department","Pyongyang Department","Tondo Department","Mushroom Kingdom Department"};
    String[] dLoc = {"Choose a Department","Pyongyang Department","Tondo Department","Mushroom Kingdom Department"};
    String[] month = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    Integer[] day = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};
    
    ImageIcon card = new ImageIcon("D:/Group 2 - Car Rental System/Images/Back1.jpg");
    JButton back = new JButton(card);
    ImageIcon card1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Next.jpg");
    JButton next = new JButton(card1);
    public Rent()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 0;
        gc.gridy = 0;
        gc.gridwidth = 2;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridwidth = 1;
        gc.gridy = 2;
        JComboBox<String> cb = new JComboBox<String>(pLoc);
        p.add(cb,gc);
        gc.gridx = 1;
        JComboBox<String> cb1 = new JComboBox<String>(dLoc);
        p.add(cb1,gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p.add(pickup,gc);
        gc.gridx = 1;
        p.add(dropoff,gc);
        gc.gridx = 0;
        gc.gridy = 4;
        JComboBox<String> cb2 = new JComboBox<String>(month);
        p.add(cb2,gc);
        gc.gridx = 1;
        JComboBox<Integer> cb3 = new JComboBox<Integer>(day);
        p.add(cb3,gc);
        gc.gridy = 3;
        p.add(pDay,gc);
        gc.gridx = 0;
        p.add(pMonth,gc);
        gc.gridy = 5;
        p.add(rMonth,gc);
        gc.gridx = 1;
        p.add(rDay,gc);
        gc.gridy = 6;
        JComboBox<Integer> cb5 = new JComboBox<Integer>(day);
        p.add(cb5,gc);
        gc.gridx = 0;
        JComboBox<String> cb4 = new JComboBox<String>(month);
        p.add(cb4,gc);
        gc.gridy = 7;
        p.add(nameL,gc);
        gc.gridx = 1;
        p.add(contactL,gc);
        gc.gridy = 8;
        p.add(contacts,gc);
        gc.gridx = 0;
        p.add(name,gc);
        gc.gridy = 9;
        p.add(back,gc);
        gc.gridx = 1;
        p.add(next,gc);
        addActionEvent();
    }
    private void addActionEvent()
    {
        back.addActionListener(this);
        next.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) 
    {
        Object source = e.getSource();
        if (source == back)
        {
            this.dispose();
            new UI().show();
        } else if (source == next)
        {
            
        }
    }
}
